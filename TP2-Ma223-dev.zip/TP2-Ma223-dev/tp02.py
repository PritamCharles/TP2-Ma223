###################################################################################
# TP02 - Ma223 - Résolution de systèmes linéaires par la méthode de Cholesky
# Auteur : Pritam Charles Kantane - 2PF2
# Date : 31/03/2021
###################################################################################
import numpy as np
import tp01_vf as tp01
from matplotlib import pyplot as plt
import time


def matriceSDP(M):
    if np.linalg.det(M) != 0:
        A = np.dot(np.transpose(M), M)
        return A
    else:
        print("La matrice n'est pas inversible.")

# Partie 1
# Question 1

def Cholesky(A):
    L = np.zeros((3, 3))
    n, p = np.shape(L)

    for k in range(n):
        somme1 = 0
        for j in range(0, k):
            somme1 += L[k, j]**2
        L[k, k] = np.sqrt(A[k, k] - somme1)

        for i in range(k + 1, n):
            somme2 = 0
            for j in range(0, k):
                somme2 += L[i, j] * L[k, j]
            L[i, k] = (A[i, k] - somme2) / L[k ,k]

    Lt = np.transpose(L)

    return L, Lt

# A = np.array([[4, -2, -4], [-2, 10, 5], [-4, 5, 6]])
# print("décomposition de A:\n", "L =\n", Cholesky(A)[0], ",\n\n", " LT =\n", Cholesky(A)[1])

# Partie 2
# Question 1

def ResolCholesky(A, B):
    L = Cholesky(A)[0]
    Lt = Cholesky(A)[1]
    tp01.ResolutionLU(L, Lt, B)

########################################################################
# GRAPHIQUES
########################################################################

# Construction de toutes les courbes

"""
def graphique_LU():
    liste_temps_LU = []
    print("temps ...")
    for i in range(3, 1003, 100):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)
        L = tp01.DecompositionLU(A)[0]
        U = tp01.DecompositionLU(A)[1]

        debut = time.time()
        tp01.ResolutionLU(L, U, B)
        fin = time.time()
        temps_exe_LU = fin - debut
        liste_temps_LU.append(temps_exe_LU)

    liste_normes_LU = []
    print("normes ...")
    for i in range(3, 1003, 100):
        Aa = np.random.rand(i, i)
        B = np.random.rand(i, 1)
        L = tp01.DecompositionLU(Aa)[0]
        U = tp01.DecompositionLU(Aa)[1]
        X = tp01.ResolutionLU(L, U, B)
        A = np.dot(L, U)

        normes_LU = np.linalg.norm(np.dot(A, X) - np.ravel(B))
        liste_normes_LU.append(normes_LU)

    print("graphique LU ...")
    plt.figure(figsize=(15, 9))
    plt.subplot(2, 1, 1)
    x = np.linspace(0, 1003, 10)
    y = np.linspace(0, 1, 3)
    plt.plot(x, liste_temps_LU, label="Méthode de décomposition LU", c="green")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Temps d'exécution (en s)")
    plt.title(
        "Graphique représentant le temps d'exécution de la méthode de décomposition LU en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()

    plt.subplot(2, 1, 2)
    plt.semilogy(x, liste_normes_LU, label="Méthode de décomposition LU", c="green")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Erreur ||AX - B||")
    plt.title(
        "Graphique représentant l'erreur ||AX - B|| de la méthode de décomposition LU en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()
    plt.savefig("LU.png")
    plt.show()


def graphique_gauss():
    liste_temps_Gauss = []
    print("temps ...")
    for i in range(3, 1003, 100):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        debut = time.time()
        tp01.Gauss(A, B)
        fin = time.time()
        temps_exe_Gauss = fin - debut
        liste_temps_Gauss.append(temps_exe_Gauss)

    liste_normes_Gauss = []
    print("normes ...")
    for i in range(3, 1003, 100):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        X = tp01.Gauss(A, B)
        normes_Gauss = np.linalg.norm(np.dot(A, X) - np.ravel(B))
        liste_normes_Gauss.append(normes_Gauss)

    print("graphique Gauss ...")
    plt.figure(figsize=(15, 9))
    plt.subplot(2, 1, 1)
    x = np.linspace(0, 1003, 10)
    y = np.linspace(0, 1, 3)
    plt.plot(x, liste_temps_Gauss, label="Méthode de Gauss", c="blue")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Temps d'exécution (en s)")
    plt.title(
        "Graphique représentant le temps d'exécution de la méthode de Gauss en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()

    plt.subplot(2, 1, 2)
    plt.semilogy(x, liste_normes_Gauss, label="Méthode de Gauss", c="blue")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Erreur ||AX - B||")
    plt.title(
        "Graphique représentant l'erreur ||AX - B|| de la méthode de Gauss en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()
    plt.savefig("Gauss.png")
    plt.show()
"""

def graphique_cholesky():
    liste_temps_Cholesky = []
    print("temps ...")
    for i in range(3, 503, 50):
        A = matriceSDP(np.random.rand(i, i))
        B = np.random.rand(i, 1)

        debut = time.time()
        ResolCholesky(A, B)
        fin = time.time()
        temps_exe_Cholesky = fin - debut
        liste_temps_Cholesky.append(temps_exe_Cholesky)

    liste_normes_Cholesky = []
    print("normes ...")
    for i in range(3, 503, 50):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        X = ResolCholesky(A, B)
        normes_Cholesky = np.linalg.norm(np.dot(A, X) - np.ravel(B))
        liste_normes_Cholesky.append(normes_Cholesky)

    print("graphique Cholesky ...")
    plt.figure(figsize=(15, 9))
    plt.subplot(2, 1, 1)
    x = np.linspace(0, 503, 10)
    y = np.linspace(0, 1, 3)
    plt.plot(x, liste_temps_Cholesky, label="Méthode de Cholesky", c="magenta")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Temps d'exécution (en s)")
    plt.title(
        "Graphique représentant le temps d'exécution de la méthode de Cholesky en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()

    plt.subplot(2, 1, 2)
    plt.semilogy(x, liste_normes_Cholesky, label="Méthode de Cholesky", c="magenta")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Erreur ||AX - B||")
    plt.title(
        "Graphique représentant l'erreur ||AX - B|| de la méthode de Cholesky en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()
    plt.savefig("Cholesky.png")
    plt.show()

"""
def graphique_linalgsolve():
    liste_temps_linalgsolve = []
    print("temps ...")

    for i in range(3, 1003, 100):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)
        debut = time.time()
        np.linalg.solve(A, B)
        fin = time.time()
        temps_exe_linalgsolve = fin - debut
        liste_temps_linalgsolve.append(temps_exe_linalgsolve)

    liste_normes_linalgsolve = []

    for i in range(3, 1003, 100):
        print("normes linalgsolve n =", i)
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        X = np.linalg.solve(A, B)
        normes_linalgsolve = np.linalg.norm(np.dot(A, X) - B)
        liste_normes_linalgsolve.append(normes_linalgsolve)

    print("graphique linalgsolve ...")
    plt.figure(figsize=(15, 9))
    plt.subplot(2, 1, 1)
    x = np.linspace(0, 1003, 10)
    y = np.linspace(0, 1, 10)
    plt.plot(x, liste_temps_linalgsolve, label="np.linalg.solve", c="black")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Temps d'exécution (en s)")
    plt.title(
        "Graphique représentant le temps d'exécution de la méthode linalg.solve de Numpy en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()

    plt.subplot(2, 1, 2)
    plt.semilogy(x, liste_normes_linalgsolve, label="np.linalg.solve", c="black")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Erreur ||AX - B||")
    plt.title(
        "Graphique représentant l'erreur ||AX - B|| de la méthode linalg.solve de Numpy en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()
    plt.savefig("linalg.solve.png")
    plt.show()


def graphique_all():
    liste_temps_LU = []
    for i in range(3, 503, 50):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)
        L = tp01.DecompositionLU(A)[0]
        U = tp01.DecompositionLU(A)[1]

        print("temps LU n =", i)
        debut = time.time()
        tp01.ResolutionLU(L, U, B)
        fin = time.time()
        temps_exe_LU = fin - debut
        liste_temps_LU.append(temps_exe_LU)

    liste_normes_LU = []
    for i in range(3, 503, 50):
        Aa = np.random.rand(i, i)
        B = np.random.rand(i, 1)
        L = tp01.DecompositionLU(Aa)[0]
        U = tp01.DecompositionLU(Aa)[1]
        X = tp01.ResolutionLU(L, U, B)
        A = np.dot(L, U)

        print("normes LU n =", i)
        normes_LU = np.linalg.norm(np.dot(A, X) - np.ravel(B))
        liste_normes_LU.append(normes_LU)

    liste_temps_Gauss = []
    for i in range(3, 503, 50):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        print("temps Gauss n =", i)
        debut = time.time()
        tp01.Gauss(A, B)
        fin = time.time()
        temps_exe_Gauss = fin - debut
        liste_temps_Gauss.append(temps_exe_Gauss)

    liste_normes_Gauss = []
    for i in range(3, 503, 50):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        print("normes Gauss n =", i)
        X = tp01.Gauss(A, B)
        normes_Gauss = np.linalg.norm(np.dot(A, X) - np.ravel(B))
        liste_normes_Gauss.append(normes_Gauss)

    liste_temps_linalgsolve = []
    for i in range(3, 503, 50):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        print("temps linalg.solve n=", i)
        debut = time.time()
        np.linalg.solve(A, B)
        fin = time.time()
        temps_exe_linalgsolve = fin - debut
        liste_temps_linalgsolve.append(temps_exe_linalgsolve)

    liste_normes_linalgsolve = []
    for i in range(3, 503, 50):
        print("normes linalgsolve n =", i)
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        X = np.linalg.solve(A, B)
        normes_linalgsolve = np.linalg.norm(np.dot(A, X) - B)
        liste_normes_linalgsolve.append(normes_linalgsolve)

    liste_temps_Cholesky = []
    for i in range(3, 503, 50):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        print("temps Cholesky n =", i)
        debut = time.time()
        ResolCholesky(A, B)
        fin = time.time()
        temps_exe_Cholesky = fin - debut
        liste_temps_Cholesky.append(temps_exe_Cholesky)

    liste_normes_Cholesky = []
    for i in range(3, 503, 50):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        print("normes Cholesky n =", i)
        X = ResolCholesky(A, B)
        normes_Cholesky = np.linalg.norm(np.dot(A, X) - np.ravel(B))
        liste_normes_Cholesky.append(normes_Cholesky)

    plt.figure(figsize=(15, 9))
    plt.subplot(2, 1, 1)
    x = np.linspace(0, 503, 10)
    y = np.linspace(0, 1, 10)
    plt.plot(x, liste_temps_Gauss, label="Gauss", c="blue")
    plt.plot(x, liste_temps_LU, label="LU", c="green")
    plt.plot(x, liste_temps_linalgsolve, label="np.linalg.solve", c="black")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Temps d'exécution (en s)")
    plt.title(
        "Graphique représentant le temps d'exécution des algorithmes en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()

    plt.subplot(2, 1, 2)
    plt.semilogy(x, liste_normes_Gauss, label="Gauss", c="blue")
    plt.semilogy(x, liste_normes_LU, label="LU", c="green")
    plt.plot(x, liste_normes_linalgsolve, label="np.linalg.solve", c="black")
    plt.xlabel("Taille de la matrice n")
    plt.ylabel("Erreur ||AX - B||")
    plt.title(
        "Graphique représentant l'erreur ||AX - B|| des algorithmes en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()
    plt.savefig("toutes_les_méthodes.png")
    plt.show()


def graphique_all_loglog():
    liste_temps_LU = []
    for i in range(3, 303, 100):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)
        L = tp01.DecompositionLU(A)[0]
        U = tp01.DecompositionLU(A)[1]

        debut = time.time()
        tp01.ResolutionLU(L, U, B)
        fin = time.time()
        temps_exe_LU = fin - debut
        liste_temps_LU.append(temps_exe_LU)

    liste_temps_Gauss = []
    for i in range(3, 303, 100):
        A = np.random.rand(i, i)
        B = np.random.rand(i, 1)

        debut = time.time()
        tp01.Gauss(A, B)
        fin = time.time()
        temps_exe_Gauss = fin - debut
        liste_temps_Gauss.append(temps_exe_Gauss)

    plt.figure(figsize=(15, 9))

    x = np.linspace(0, 303, 3)
    y = np.linspace(0, 1, 3)
    plt.plot(np.log(x), np.log(liste_temps_Gauss), label="Gauss", c="blue")
    plt.plot(np.log(x), np.log(liste_temps_LU), label="LU", c="green")
    plt.xlabel("log Taille de la matrice n")
    plt.ylabel("log Temps d'exécution (en s)")
    plt.title(
        "Graphique représentant le temps d'exécution de la décomposition LU en fonction de la taille de la matrice")
    plt.legend()
    plt.grid()
    plt.savefig("toutes_les_méthodes_log_log.png")
    plt.show()


#############################################

# graphique_gauss()
# graphique_LU()
# graphique_linalgsolve()
# graphique_all()
# graphique_all_loglog()"""

graphique_cholesky()

